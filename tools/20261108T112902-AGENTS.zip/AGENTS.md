# AGENTS.md: keepersofsin

<!-- Generated 20261108T112902 by new-agents.ps1 -->

Contracts live in `contracts/`. Use only the contracts listed here.

1. Read every **Core** contract before any work.
2. Read a **When relevant** contract only when the task touches its subject.
3. Adopt a **Role** only when the human assigns it (e.g. "act as QA"), then read that file.
4. Read a **Tools** contract before using that tool.
5. Precedence: tool/system instructions > core > workflow > domain > tools > multi-agent > role > provider. Lower layers may tighten rules, never weaken them.

## Core

| ID | File | Summary |
|---|---|---|
| CORE-AI-FOLDER | `contracts/core/ai-folder.md` | Agents keep their own working files in .ai/; common/ is shared, one folder per agent. |
| CORE-AUTHORITY | `contracts/core/authority.md` | What grants authority, what needs human approval, conflicts, stops, exceptions. |
| CORE-COMPLETION | `contracts/core/completion.md` | Pre-submission review, completion gates, status claims, and the final report. |
| CORE-EVIDENCE | `contracts/core/evidence.md` | Honesty and evidence rules: labels, citations, checks, and what may be claimed. |
| CORE-PRINCIPLES | `contracts/core/principles.md` | Purpose and governing principles for any AI-assisted work. |
| CORE-TERMS | `contracts/core/terms.md` | Defined vocabulary used by every contract. Load first. |

## When relevant

| ID | File | Summary |
|---|---|---|
| WF-BINDING | `contracts/workflow/binding.md` | Where the project's authoritative records live (docs/workflow.md). |
| WF-PLANNING | `contracts/workflow/planning.md` | Intent vs design vs authorized work; one active increment; promotion gates. |
| WF-RECORDS | `contracts/workflow/records.md` | Minimal work records; intake and triage of requests, defects, and feedback. |
| WF-STATE | `contracts/workflow/state.md` | Agent handoff, temporary state, memory limits, and retention budgets. |
| WF-WORKSPACE | `contracts/workflow/workspace.md` | Shared folder conventions (Reports/, Reference/, .ai/, docs/); create only what is needed. |
| LIT-CANON | `contracts/literature/canon.md` | Premise, story bible, and style sheet as canonical records; canon vs proposed. |
| LIT-CONTROL | `contracts/literature/creative-control.md` | The author's creative authority; what an agent may change, suggest, or never touch. |
| LIT-MANUSCRIPT | `contracts/literature/manuscript.md` | Manuscript stages, increments, file layout, and versioning. |
| LIT-ORIGINALITY | `contracts/literature/originality.md` | Originality, copyright, quotation, research sourcing, AI-use disclosure. |
| LIT-QUALITY | `contracts/literature/quality.md` | Literary quality checks, how to report them, and the publication-ready gate. |
| MA-ASSIGN | `contracts/multi-agent/assignment.md` | How to split work across agents and match agents to roles. |
| MA-COORD | `contracts/multi-agent/coordination.md` | Several agents on one project: shared authority, leases, integrator, handoffs, conflicts. |

## Roles (on request)

| ID | File | Summary |
|---|---|---|
| ROLE-BETA-READER | `contracts/roles/simulated/beta-reader.md` | Simulated target reader reporting engagement chapter by chapter. |
| ROLE-COPY-EDITOR | `contracts/roles/literature/copy-editor.md` | Grammar, usage, consistency, and style-sheet conformance; queries ambiguity. |
| ROLE-CO-WRITER | `contracts/roles/literature/co-writer.md` | Drafts scenes or chapters from the author's outline, in the author's voice. |
| ROLE-CRITIC | `contracts/roles/simulated/critic.md` | Simulated professional critical review: craft, themes, originality, genre context. |
| ROLE-DEV-EDITOR | `contracts/roles/literature/developmental-editor.md` | Big-picture edit: structure, plot, character arcs, pacing, theme, audience fit. |
| ROLE-END-USER | `contracts/roles/simulated/end-user.md` | Simulated typical user attempting real tasks with the product or work. |
| ROLE-LINE-EDITOR | `contracts/roles/literature/line-editor.md` | Sentence- and paragraph-level craft: clarity, rhythm, word choice, voice. |
| ROLE-PROOFREADER | `contracts/roles/literature/proofreader.md` | Final pass for typos, formatting, and layout errors; minimal changes. |
| ROLE-PUBLISHING-AGENT | `contracts/roles/literature/publishing-agent.md` | Assesses market readiness; drafts query letter, synopsis, and submission package. |
| ROLE-READER-REVIEW | `contracts/roles/simulated/reader-review.md` | Simulated public reader review (star rating) to preview reception. |
| ROLE-SIMULATED | `contracts/roles/simulated/_simulated.md` | Shared rules for every simulated persona (reviewer, critic, reader, end user). |

## Providers

| ID | File | Summary |
|---|---|---|
| PROV-CLAUDE | `contracts/providers/anthropic.md` | Claude / Claude Code discovery and feature mapping. |
| PROV-COPILOT | `contracts/providers/copilot.md` | GitHub Copilot discovery and path-scoped instructions. |
| PROV-DEEPSEEK | `contracts/providers/deepseek.md` | DeepSeek models used through a third-party harness or chat. |
| PROV-OPENAI | `contracts/providers/openai.md` | ChatGPT / OpenAI Codex discovery and usage notes. |

## Project rules

- None yet. Keep additions short; prefer editing a contract.
