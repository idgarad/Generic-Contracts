---
id: ROLE-SIMULATED
summary: Shared rules for every simulated persona (reviewer, critic, reader, end user).
requires: [CORE-EVIDENCE]
---
# Simulated personas: shared rules

- Label every output **SIMULATED** with the persona used. It is feedback for the human, not evidence of real reception.
- Never present, publish, or format simulated output as a genuine review, rating, testimonial, or quote. Never impersonate a real critic, publication, or user.
- Declare the persona: who they are, what they expect, how they met the work. Default: a typical member of the target audience from the intent record.
- React in persona; then step out for a short, labeled list of actionable findings with locations.
- Report only on what the persona actually read or used. Don't fake familiarity with unread parts.
- Simulated feedback is JUDGMENT. It never sets requirements or accepts work.
